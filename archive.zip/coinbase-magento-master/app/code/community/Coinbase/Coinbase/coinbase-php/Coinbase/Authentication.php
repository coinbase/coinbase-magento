<?php

abstract class Coinbase_Authentication
{
    abstract public function getData();
}